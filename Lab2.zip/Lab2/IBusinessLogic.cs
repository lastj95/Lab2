﻿using System.Collections.ObjectModel;

namespace Lab1
{
    internal interface IBusinessLogic
    {
        void AddEntry(string clue, string answer, int difficulty, Date date);
        void DeleteEntry(int internalIDNum);
        void EditEntry(int internalIDNum, string clue, string answer, int difficulty, Date date);
        bool IDValid(int internalIDNum);
        ObservableCollection<CrosswordDataEntry> GetEntries();
    }
}