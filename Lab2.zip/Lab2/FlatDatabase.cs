﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace Lab1
{
    /// <summary>
    /// FlatDatabase is the class of this overall program which writes and reads CrosswordDataEntries to and from a file, so that the BusinessLogic class may
    /// interpret the resulting List.
    /// <author>James Last</author>
    /// </summary>
    internal class FlatDatabase : IFlatDatabase
    {
        //The relative filepath to where data is stored and retrieved.
        public static String appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        public static String filename = $"{appDataPath}/clues.json";

        /// <summary>
        /// Retrieves the stored List of CrosswordDataEntries from the data file upon request.
        /// </summary>
        /// <author>James Last</author>
        /// <returns></returns>
        public ObservableCollection<CrosswordDataEntry> ReadFromDatabase()
        {
            if (File.Exists(filename))
            {
                String jsonString = File.ReadAllText(filename);
                ObservableCollection<CrosswordDataEntry>? dataPresent = JsonSerializer.Deserialize<ObservableCollection<CrosswordDataEntry>>(jsonString);
                if (dataPresent is not null)
                {
                    return dataPresent;
                }
                else
                {
                    ObservableCollection<CrosswordDataEntry> empty = new ObservableCollection<CrosswordDataEntry>();
                    return empty;
                }
            }
            else
            {
                ObservableCollection<CrosswordDataEntry> empty = new ObservableCollection<CrosswordDataEntry>();
                return empty;
            }
        }

        /// <summary>
        /// Writes the List of CrosswordDataEntries to the data file upon request.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="crosswordData"></param>
        public void WriteToDatabase(ObservableCollection<CrosswordDataEntry> crosswordData)
        {
            JsonSerializerOptions options = new JsonSerializerOptions { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(crosswordData, options);
            File.WriteAllText(filename, jsonString);
        }
    }
}
