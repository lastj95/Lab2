﻿using Lab1;
using System.Collections.ObjectModel;

namespace Lab2;

/// <summary>
/// The MainPage encompasses the UI of the overall app. Users may add, delete, or edit data via the buttons, and additions, deletions, and edits will be made based on
/// what the user has entered into the text fields.
/// </summary>
public partial class MainPage : ContentPage
{
	IBusinessLogic logic = new BusinessLogic();
	ObservableCollection<CrosswordDataEntry> crosswordDataEntries;


    public MainPage()
	{
        InitializeComponent();
        crosswordDataEntries = logic.GetEntries();
		CrosswordDataLV.ItemsSource = crosswordDataEntries;
    }

	/// <summary>
	/// Gets the data from the entry fields in order to send required data for adding an entry down to businessLogic.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	private async void OnAddEntryClicked(object sender, EventArgs e)
	{
		String clue;
		String answer;
		int difficulty;
		int month;
		int day;
		int year;
		Date date;

		//Attempts to grab from entry fields.
		try
		{
			clue = Clue.Text;
			if (clue == null || clue.Length < 1)
			{
				throw new NullReferenceException();
			}

			answer = Answer.Text;
			if (answer == null || answer.Length < 1)
			{
				throw new NullReferenceException();
			}

			difficulty = int.Parse(Difficulty.Text);
			if (difficulty < 0 || difficulty > 2)
			{
				throw new FormatException();
			}

			month = int.Parse(Month.Text);
			day = int.Parse(Day.Text);
			year = int.Parse(Year.Text);
			date = new Date(month, day, year);

			//Passes info to businessLogic.
			logic.AddEntry(clue, answer, difficulty, date);
			crosswordDataEntries = logic.GetEntries();
			CrosswordDataLV.ItemsSource = crosswordDataEntries;
        } 
		catch (NullReferenceException)
		{
			await DisplayAlert("Error in Entry: No Data in Field(s)", "Please ensure all requisite entry fields are filled.", "OK");
		}
		catch (ArgumentNullException)
		{
            await DisplayAlert("Error in Entry: No Data in Field(s)", "Please ensure all requisite entry fields are filled.", "OK");
        }
		catch (FormatException)
		{
			await DisplayAlert("Error in Entry: Incorrect Data Type in Field(s)", "Please ensure numeric fields contain integer values within the given/logical ranges.", "OK");
		}
		catch (DateRangeException)
		{
			await DisplayAlert("Error in Entry: Non-Existent Date Entered", "Please ensure month, day, and year fields constitute an existing day.", "OK");
		}
	}

	private void OnDeleteEntryClicked(object sender, EventArgs e)
	{

	}

	private void OnEditEntryClicked(object sender, EventArgs e)
	{

	}
}

