﻿using System.Collections.ObjectModel;

namespace Lab1
{
    internal interface IFlatDatabase
    {
        ObservableCollection<CrosswordDataEntry> ReadFromDatabase();
        void WriteToDatabase(ObservableCollection<CrosswordDataEntry> crosswordData);
    }
}