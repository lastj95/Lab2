﻿namespace Lab2;


/// <summary>
/// Name: James Last
/// Description: Lab 2
/// Date: 9/27/2022
/// Bugs: While the deletion and edit functions not being written are more of missing features than bugs, I am listing them here anyways. The major bug I have not been
/// able to solve after hours of asking around and Googling was how to sync up my ListView and get it to display properly. I've tried a range of ways to tackle the issue
/// including attempting to make my crossword object observable as shown in the lab last week, however even that hasn't properly worked. Currently, adding entries does produce
/// a graphical anomally where the ListView should be (well, above and below where it should be anyways), however it's almost as if the text is invisible.
/// 
/// Reflection:  I hate to turn in this lab incomplete, especially with the state that it's in (and how I was able to gracefully handle input in the one button I did code),
/// but as discussed a lot already within this class, learning to accept failure gracefully and learn from it can be more valuable than successes at times. I've been
/// able to learn a ton of .NET MAUI's structure as well as learn how difficult it is to reconcile old code from one framework into another, while also learning the latter
/// framework at the same time. Admittedly there are a few outside factors in my life right now that are affecting how much I can push myself in these circumstances.
/// Changes such as the death of my mother and my father having to work far more to support the remaining family have left me in a role of guidance for my little sister
/// as well as a lot of pressure from others, and especially from myself internally, to take on as much as I can and push myself. This isn't an excuse for my inability
/// to finish the project properly, but I do offer it as an honest and open explanation.
/// 
/// I'm choosing to turn this in incomplete as opposed to "ghosting" the lab altogether not just so that I may get partial credit for some of
/// what I was able to accomplish, but so that I may be forward, honest, and accepting with and of my failure, in the hope of growing for any and all future projects
/// in this class and beyond. Here's to hoping that Lab 3 is a fresh start!
/// </summary>
public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});

		return builder.Build();
	}
}
