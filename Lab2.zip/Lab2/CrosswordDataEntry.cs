﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Lab1
{
    [Serializable]

    /// <summary>
    /// A CrosswordDataEntry object has parameters restricted by the BusinessLogic class, except in the case of the Date object parameter date that is handled within
    /// the date class itself. Users may retrieve parameters individually and modify them together. IDs, however, are unique as in they are UNCHANGEABLE so that order may
    /// be maintained. In a List environment, the entries are retrieved from their index, acting as a "visible" ID to the user.
    /// <author>James Last</author>
    /// </summary>
    public class CrosswordDataEntry : ISerializable, IComparable<CrosswordDataEntry>
    {
        public String clue { get; set; }
        public String answer { get; set; }
        public int difficulty { get; set; }
        public Date date { get; set; }
        public int internalID { get; set; }

        /// <summary>
        /// Creates a new CrosswordDataEntry object.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="clue"></param>
        /// <param name="answer"></param>
        /// <param name="difficulty"></param>
        /// <param name="date"></param>
        public CrosswordDataEntry(string clue, string answer, int difficulty, Date date, int internalID)
        {
            this.clue = clue;
            this.answer = answer;
            this.difficulty = difficulty;
            this.date = date;
            this.internalID = internalID;
        }

        /// <summary>
        /// Modifies entry parameters all at once, with the exception of the id number which is not directly editable without deletion of an entry.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="clue"></param>
        /// <param name="answer"></param>
        /// <param name="difficulty"></param>
        /// <param name="date"></param>
        public void modify(string clue, string answer, int difficulty, Date date)
        {
            this.clue = clue;
            this.answer = answer;
            this.difficulty = difficulty;
            this.date = date;
        }


        /// <summary>
        /// Allows the CrosswordDataEntry class to be properly Serializable.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="info"></param>
        /// <param name="context"></param>
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("clue", clue);
            info.AddValue("answer", answer);
            info.AddValue("difficulty", difficulty);
            info.AddValue("date", date);
            info.AddValue("id", internalID);
        }

        /// <summary>
        /// Allows the CrosswordDataEntry class to be properly Comparable and Sortable.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="otherEntry"></param>
        /// <returns></returns>
        public int CompareTo(CrosswordDataEntry? otherEntry)
        {
            if (otherEntry is not null)
            {
                return this.internalID - otherEntry.internalID;
            }
            else
            {
                return 1;
            }

        }

    }
}
