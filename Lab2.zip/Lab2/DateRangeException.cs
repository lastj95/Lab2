﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    /// <summary>
    /// Custom exception for when a Date object's values are out of range.
    /// <author>James Last</author>
    /// </summary>
    public class DateRangeException : Exception
    {
        public DateRangeException() { }
            
    }
}
