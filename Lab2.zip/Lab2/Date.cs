﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Dynamic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Lab1

{
    [Serializable]

    /// <summary>
    /// Class <c>Date</c> is an object that has month, day, and year parameters which can be freely modified as well as retrieved together.
    /// <author>James Last</author>
    /// </summary>
    public class Date : ISerializable, IComparable<Date>
    {

        public int month { get; private set; }
        public int day { get; private set; }
        public int year { get; private set; }

        /// <summary>
        /// Creates the Date object. Validates inputted month, day, and year values BEFORE creation to ensure integrity.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <param name="year"></param>
        public Date(int month, int day, int year)
        {
            validation(month, day, year);
            this.month = month;
            this.day = day;
            this.year = year;
        }
        
        /// <summary>
        /// Ensures date given by user is valid before actually creating Date object's parameters, and throws exception if Date values are invalid.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <param name="year"></param>
        public void validation(int month, int day, int year)
        {
            bool validDate = true;

            //Checks month value.
            if (month < 1 || month > 12)
            {
                validDate = false;
            }
            //Checks day value, accounts for leap years.
            else if (day < 1)
            {
                validDate = false;
            }
            else
            {
                switch(month)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                    case 12:
                        if (day > 31)
                        {
                            validDate = false;
                        }
                        break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        if (day > 30)
                        {
                            validDate = false;
                        }
                        break;
                    case 2:

                        int febDays = 28;

                        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                        {
                            febDays = 29;
                        }

                        if (day > febDays)
                        {
                            validDate = false;
                        }
                        break;
                    default:
                        Console.WriteLine("If code somehow went here, something's horribly wrong with date checking!!!");
                        break;
                }


            }

            //If any part of the date is shown to have invalid data, an exception is thrown.
            if (!validDate)
            {
                throw new DateRangeException();
            }

        }

        /// <summary>
        /// Allows the Data class to be properly Serializable.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="info"></param>
        /// <param name="context"></param>
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("month", month);
            info.AddValue("day", day);
            info.AddValue("year", year);
        }

        /// <summary>
        /// Allows the Date class to be properly Comparable and Sortable.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="otherDate"></param>
        /// <returns></returns>
        public int CompareTo(Date? otherDate)
        {
            if (otherDate is not null)
            {
                if (this.year != otherDate.year)
                {
                    return this.year - otherDate.year;
                }
                else if (this.month != otherDate.month)
                {
                    return this.month - otherDate.month;
                }
                else
                {
                    return this.day - otherDate.day;
                }
            }
            else
            {
                return 1;
            }
            
        }

    }
}