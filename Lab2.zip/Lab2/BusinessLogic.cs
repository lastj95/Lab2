﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    /// <summary>
    /// The BusinessLogic class of this program retrieves commands from the user that are interpreted in the UserInterface class and interfaces with the
    /// FlatDatabase class in order to retrieve data for the purpose of manipulation. In essence, this class is a middleman between the "front" and "back" ends
    /// of the program at large.
    /// <author>James Last</author>
    /// </summary>
    internal class BusinessLogic : IBusinessLogic
    {

        IFlatDatabase database = new FlatDatabase();

        /// <summary>
        /// Gets CrosswordDataEntries.
        /// </summary>
        /// <author>James Last</author>
        /// <returns></returns>
        public ObservableCollection<CrosswordDataEntry> GetEntries()
        {
            return database.ReadFromDatabase();
        }

        /// <summary>
        /// Generates a new CrosswordDataEntry object to be put into the list for storing via FlatDatabase.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="clue"></param>
        /// <param name="answer"></param>
        /// <param name="difficulty"></param>
        /// <param name="date"></param>
        public void AddEntry(String clue, String answer, int difficulty, Date date)
        {
            //Adds new entry to database.
            ObservableCollection<CrosswordDataEntry> crosswordData = (database.ReadFromDatabase());
            CrosswordDataEntry newEntry = new CrosswordDataEntry(clue, answer, difficulty, date, (crosswordData.Count + 1));
            crosswordData.Add(newEntry);
            database.WriteToDatabase(crosswordData);
        }

        /// <summary>
        /// Deletes the entry specified by the user in UserInterface.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="internalIDNum"></param>
        /// <returns></returns>
        public void DeleteEntry(int internalIDNum)
        {
            ObservableCollection<CrosswordDataEntry> crosswordData = database.ReadFromDatabase();

            crosswordData.RemoveAt(internalIDNum - 1);

            //Re-assigns internal ID numbers after deletion of an entry.
            for (int i = 0; i < crosswordData.Count; i++)
            {
                crosswordData[i].internalID = i + 1;
            }

            //Writes modified list back.
            database.WriteToDatabase(crosswordData);
        }

        /// <summary>
        /// Edits the entry specified by the user in UserInterface.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="internalIDNum"></param>
        /// <param name="clue"></param>
        /// <param name="answer"></param>
        /// <param name="difficulty"></param>
        /// <param name="date"></param>
        public void EditEntry(int internalIDNum, String clue, String answer, int difficulty, Date date)
        {
            ObservableCollection<CrosswordDataEntry> crosswordData = database.ReadFromDatabase();

            //Modifies data in the list.
            crosswordData[internalIDNum - 1].clue = clue;
            crosswordData[internalIDNum - 1].answer = answer;
            crosswordData[internalIDNum - 1].difficulty = difficulty;
            crosswordData[internalIDNum - 1].date = date;

            //Writes list back.
            database.WriteToDatabase(crosswordData);
        }

        /// <summary>
        /// Checks the upper bound of the list to ensure an ID being referenced is valid.
        /// </summary>
        /// <author>James Last</author>
        /// <param name="internalIDNum"></param>
        /// <returns></returns>
        public bool IDValid(int internalIDNum)
        {
            bool success = false;

            ObservableCollection<CrosswordDataEntry> crosswordData = database.ReadFromDatabase();

            if (internalIDNum <= crosswordData.Count)
            {
                success = true;
            }

            return success;
        }
    }
}
